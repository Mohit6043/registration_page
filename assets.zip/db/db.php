<?php 
$server = "localhost";
$username = "root";
$password = "";
$dbname = "eventribe";

$con = mysqli_connect($server, $username, $password, $dbname);

?>